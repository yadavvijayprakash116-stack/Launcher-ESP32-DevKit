#include <Arduino.h>
#include <SPI.h>
#include <Arduino_GFX_Library.h>

#define TFT_CS 27
#define TFT_DC 26
#define TFT_RST 25
#define TFT_SCK 18
#define TFT_MOSI 23
#define TFT_MISO 19
#define TOUCH_CS 33

Arduino_DataBus *bus = new Arduino_ESP32SPI(TFT_DC, TFT_CS, TFT_SCK, TFT_MOSI, TFT_MISO, VSPI, true);
Arduino_GFX *gfx = new Arduino_ILI9341(bus, TFT_RST, 1, false, 240, 320);

static constexpr uint16_t WHITE = 0xFFFF;
static constexpr uint16_t BLACK = 0x0000;
static constexpr uint16_t GREEN = 0x07E0;
static constexpr uint16_t RED = 0xF800;

static uint16_t read12(uint8_t cmd) {
  SPI.beginTransaction(SPISettings(2500000, MSBFIRST, SPI_MODE0));
  digitalWrite(TOUCH_CS, LOW);
  SPI.transfer(cmd);
  uint16_t v = ((uint16_t)SPI.transfer(0x00) << 8) | SPI.transfer(0x00);
  digitalWrite(TOUCH_CS, HIGH);
  SPI.endTransaction();
  return (v >> 3) & 0x0FFF;
}

static bool readTouch(uint16_t &x, uint16_t &y, uint16_t &z) {
  SPI.beginTransaction(SPISettings(2500000, MSBFIRST, SPI_MODE0));
  digitalWrite(TOUCH_CS, LOW);
  uint16_t z1 = (((uint16_t)SPI.transfer(0xB1) << 8) | SPI.transfer(0x00)) >> 3;
  uint16_t z2 = (((uint16_t)SPI.transfer(0xC1) << 8) | SPI.transfer(0x00)) >> 3;
  uint16_t xr = (((uint16_t)SPI.transfer(0x91) << 8) | SPI.transfer(0x00)) >> 3;
  uint16_t yr = (((uint16_t)SPI.transfer(0xD1) << 8) | SPI.transfer(0x00)) >> 3;
  digitalWrite(TOUCH_CS, HIGH);
  SPI.endTransaction();

  int p = (int)z1 + 4095 - (int)z2;
  if (p < 0) p = 0;
  z = (uint16_t)p;
  x = xr;
  y = yr;
  return z > 100;
}

void draw(uint16_t x, uint16_t y, uint16_t z, bool pressed) {
  gfx->fillScreen(BLACK);
  gfx->setTextColor(WHITE);
  gfx->setTextSize(2);
  gfx->setCursor(12, 15); gfx->println("XPT2046 RAW TEST");
  gfx->setTextSize(1);
  gfx->setCursor(12, 45); gfx->println("CS=33  CLK=18  DIN=23  DO=19");
  gfx->setTextSize(2);
  gfx->setCursor(12, 80); gfx->printf("RAW X = %u", x);
  gfx->setCursor(12, 115); gfx->printf("RAW Y = %u", y);
  gfx->setCursor(12, 150); gfx->printf("RAW Z = %u", z);
  gfx->setCursor(12, 200);
  gfx->setTextColor(pressed ? GREEN : RED);
  gfx->println(pressed ? "TOUCH: YES" : "TOUCH: NO");
  gfx->setTextColor(WHITE);
  gfx->setTextSize(1);
  gfx->setCursor(12, 245); gfx->println("Touch anywhere. Values must change.");
  gfx->setCursor(12, 270); gfx->println("Hardware SPI direct test");
}

void setup() {
  Serial.begin(115200);
  pinMode(TFT_CS, OUTPUT); digitalWrite(TFT_CS, HIGH);
  pinMode(TOUCH_CS, OUTPUT); digitalWrite(TOUCH_CS, HIGH);
  SPI.begin(TFT_SCK, TFT_MISO, TFT_MOSI, -1);
  gfx->begin();
  gfx->setRotation(1);
  draw(0,0,0,false);
  Serial.println("XPT2046 direct hardware-SPI test started");
}

void loop() {
  static uint32_t last = 0;
  uint16_t x,y,z;
  bool pressed = readTouch(x,y,z);
  if (millis() - last >= 100) {
    Serial.printf("X=%u Y=%u Z=%u TOUCH=%s\n", x,y,z,pressed?"YES":"NO");
    draw(x,y,z,pressed);
    last = millis();
  }
  delay(20);
}
