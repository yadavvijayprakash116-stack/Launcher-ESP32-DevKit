#include <Arduino.h>
#include <Arduino_GFX_Library.h>
#include <CYD28_TouchscreenR.h>

#define TFT_CS 27
#define TFT_DC 26
#define TFT_RST 25
#define TFT_SCK 18
#define TFT_MOSI 23
#define TFT_MISO 19

Arduino_DataBus *bus = new Arduino_ESP32SPI(TFT_DC, TFT_CS, TFT_SCK, TFT_MOSI, TFT_MISO, VSPI, true);
Arduino_GFX *gfx = new Arduino_ILI9341(bus, TFT_RST, 1, false, 240, 320);
CYD28_TouchR touch(320, 240);

static void drawScreen(bool pressed, int x, int y, int z) {
  gfx->fillScreen(BLACK);
  gfx->setTextColor(WHITE);
  gfx->setTextSize(2);
  gfx->setCursor(18, 15);
  gfx->println("XPT2046 TOUCH TEST");
  gfx->setTextSize(1);
  gfx->setCursor(18, 48);
  gfx->println("Wiring: 18/23/19/33, IRQ unused");
  gfx->setTextSize(2);
  gfx->setCursor(18, 85);
  gfx->print("X = "); gfx->println(x);
  gfx->setCursor(18, 120);
  gfx->print("Y = "); gfx->println(y);
  gfx->setCursor(18, 155);
  gfx->print("Z = "); gfx->println(z);
  gfx->setCursor(18, 200);
  gfx->setTextColor(pressed ? GREEN : RED);
  gfx->println(pressed ? "TOUCH: YES" : "TOUCH: NO");
  gfx->setTextColor(WHITE);
  gfx->setCursor(18, 245);
  gfx->println("Touch anywhere on screen");
  gfx->setCursor(18, 275);
  gfx->println("Software SPI touch test");
}

void setup() {
  Serial.begin(115200);
  delay(300);
  gfx->begin();
  gfx->setRotation(1);
  gfx->fillScreen(BLACK);
  gfx->setTextColor(WHITE);
  gfx->setTextSize(2);
  gfx->setCursor(20, 20);
  gfx->println("Starting touch test...");
  bool ok = touch.begin(); // IMPORTANT: bit-banged SPI on GPIO 18/23/19
  Serial.printf("XPT2046 begin: %s\n", ok ? "OK" : "FAIL");
  delay(500);
  drawScreen(false, 0, 0, 0);
}

void loop() {
  static uint32_t lastDraw = 0;
  bool p = touch.touched();
  if (p) {
    CYD28_TS_Point q = touch.getPointScaled();
    Serial.printf("TOUCH X=%d Y=%d Z=%d\n", q.x, q.y, q.z);
    if (millis() - lastDraw > 80) {
      drawScreen(true, q.x, q.y, q.z);
      lastDraw = millis();
    }
  } else if (millis() - lastDraw > 250) {
    drawScreen(false, 0, 0, 0);
    lastDraw = millis();
  }
  delay(20);
}
